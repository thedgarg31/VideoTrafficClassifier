# Technical Stack

This file lists the technical stack.