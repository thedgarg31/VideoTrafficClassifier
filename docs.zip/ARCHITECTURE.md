# Architecture

This file describes the architecture.